import streamlit as st
from PIL import Image

st.set_page_config(
    page_title="    Image to Text stegangraphy",
    page_icon="👋",
)

st.title("Image/Text Steganography")



image = Image.open('image_img2txt.jpeg')

st.image(image, caption='Steganography')

st.sidebar.success("Select the operation.")

