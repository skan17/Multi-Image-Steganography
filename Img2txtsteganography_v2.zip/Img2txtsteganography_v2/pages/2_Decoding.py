import streamlit as st
from PIL import Image

st.title("Decoding Tab")

def decode():
    print(data2)
    image = Image.open(data2, 'r')
    
    data = ''
    imgdata = iter(image.getdata())
 
    while (True):
        pixels = [value for value in imgdata.__next__()[:3] +
                                imgdata.__next__()[:3] +
                                imgdata.__next__()[:3]]
 
        # string of binary data
        binstr = ''
 
        for i in pixels[:8]:
            if (i % 2 == 0):
                binstr += '0'
            else:
                binstr += '1'
 
        data += chr(int(binstr, 2))
        if (pixels[-1] % 2 != 0):
            st.write("Encrypted text : ",data)
            return data

data2 = st.text_input('Enter the filename to decode')
res = st.button('Decode',on_click = decode)

print(res)